package pryradiobutton;

import View.OperacionesVista;

public class PryRadioButton {

    public static void main(String[] args) {
        OperacionesVista op=new OperacionesVista();
        op.setVisible(true);
    }
    
}
